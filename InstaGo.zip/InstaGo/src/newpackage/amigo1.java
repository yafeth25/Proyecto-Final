/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static newpackage.principal.panel6;


public class amigo1 extends JFrame{
    
    public amigo1()
    {
        this.setSize(315, 500);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
      //  this.setDefaultCloseOperation(EXIT_ON_CLOSE);
     
        inciarsesion6();
    }
    
    
     private void inciarsesion6()
    {
       
        panel6=new JPanel();
        this.getContentPane().add(panel6);
        panel6.setLayout(null); 
        
        JLabel text = new JLabel ();
        text.setText("Lista de Amigos");
        text.setForeground(Color.white);
        text.setFont(new Font ("Arial Black",Font.PLAIN,18));
        text.setBounds(73, 38, 200, 28);
           
        panel6.add(text);
         
        JLabel bienvenida = new JLabel ();
       // fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
        bienvenida.setForeground(Color.black);
       bienvenida.setBounds(0, 200, 400, 500);
        panel6.add(bienvenida);
        
 
        JButton boton12=new JButton ();
     
        boton12.setText("Yafeth Sanchez");
         boton12.setFont(new Font ("Arial Black",Font.PLAIN,18));
         boton12.setForeground(Color.black);
         boton12.setBackground(Color.white);
         boton12.setBorder(null);
         boton12.setBounds(-20, 70, 260, 28);
        
        panel6.add(boton12);
        
         ActionListener ami1 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                chat2 op3=new chat2();
                op3.show();
                dispose();
            }
        };
        
         boton12.addActionListener(ami1);
        
          JButton boton11=new JButton ();
        boton11.setText("Volver");
        boton11.setFont(new Font ("Arial Black",Font.PLAIN,18));
        boton11.setForeground(Color.white);
         boton11.setBackground(Color.black);
         boton11.setBorder(null);
        boton11.setBounds(0, 415, 144, 25);
     //   boton11.setIcon(new ImageIcon("imagenes/Enviar.png"));
        
        panel6.add(boton11);
    
         ActionListener B = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                principal op3=new principal();
                op3.show();
                dispose();
            }
        };
        
         boton11.addActionListener(B);
        
        
         JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
        fondo2.setBounds(0, -20, 400, 500);
        panel6.add(fondo2);
        
    }
    
    
}
