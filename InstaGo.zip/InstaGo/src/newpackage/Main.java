
package newpackage;

/**
 *
 * @author Norman
 */
public class Main {

    public static void main(String[] args) {
        MenuPrincipal ope=new MenuPrincipal();
        
      ope.setVisible(true);
        
        chat1 chat4 = new chat1 ();
      //chat4.setVisible(true);
        
        chat2 chat = new chat2 ();
       //chat.setVisible(true);
        
       principal ope2=new principal();
     //  ope2.setVisible(true);
      
     inicio op3=new inicio();
    //op3.setVisible(true);
     
    amigo2 ope6=new amigo2();
    //ope6.setVisible(true);
            
         
     
    }

    
}
        