
package newpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import static newpackage.chat1.area;


public class chat2 extends JFrame{

    public static JTextArea area2;
   
     
    
public chat2()
{
        this.setSize(315, 500);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
        
        iniciar5();
    
}
          protected  void iniciar5()
        {
        
        JPanel panel4=new JPanel();
        this.getContentPane().add(panel4);
        panel4.setLayout(null); 
        //panel4.setBackground(Color.black);
        
        JLabel chat=new JLabel();
        chat.setText("Yafeth Sanchez");
        chat.setFont(new Font("Arial Rounded MT",Font.PLAIN,15));
        chat.setForeground(Color.white);
        chat.setBackground(Color.red);
        chat.setBounds(100, 20, 200, 25);
        
        
        panel4.add(chat);
        
         JButton boton13=new JButton ();
     
        
        
         boton13.setIcon(new ImageIcon("imagenes/Atras.png"));
         boton13.setBackground(Color.black);
         boton13.setBorder(null);
         boton13.setBounds(265, 20, 27, 28);
        
        panel4.add(boton13);
          ActionListener amigo1 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                amigo1 op3=new amigo1();
                op3.show();
                dispose();
            }
        };
        boton13.addActionListener(amigo1);
       
        
       JTextField cajat1=new  JTextField();
       cajat1.setFont(new Font("System",Font.PLAIN,15));
       cajat1.setBorder(null);
       cajat1.setBackground(Color.white);
       cajat1.setForeground(Color.black);
       cajat1.setBounds(24, 421, 225, 35);
   
        panel4.add(cajat1);
        
        area2=new JTextArea();
        area2.setFont(new Font("System",Font.PLAIN,13));
        area2.setBounds(0, 63, 300, 350);
        area2.setLineWrap(true);
        
         
        panel4.add(area2);
        
        
      
        
       JButton boton7=new JButton ();
        // boton7.setText("Enviar");
         boton7.setBackground(Color.black);
         boton7.setBorder(null);
        boton7.setBounds(265, 426, 27, 25);
        boton7.setIcon(new ImageIcon("imagenes/Enviar.png"));
        
        panel4.add(boton7);
        
         JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/CHAT.png"));
        fondo2.setBounds(0, -20, 400, 500);
        panel4.add(fondo2);
        
        
        ActionListener accion1 = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                 if(cajat1.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, " Campo Vacio ", "Texto",JOptionPane.QUESTION_MESSAGE);
        }
        else
        {
                
                area.append("--------------------------"+"\n"+"  De Yafeth: "+cajat1.getText()+"\n\n");  
                area2.append("\t\t......................"+"\n"+"\t\t    Tu: "+cajat1.getText()+"\n\n");
                 cajat1.setText("");
        }    

            }
        };
        
      boton7.addActionListener(accion1);
            
        
        
        }
       

}
