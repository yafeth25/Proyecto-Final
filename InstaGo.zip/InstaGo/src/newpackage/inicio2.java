/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static newpackage.principal.panel6;


public class inicio2  extends JFrame {
    
      public inicio2()
   {
         this.setSize(315, 500);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
       // this.setDefaultCloseOperation(EXIT_ON_CLOSE);   
        inciarsesion3();
    }
    
      private void inciarsesion3()
    {
       
        
         panel6=new JPanel();
        this.getContentPane().add(panel6);
        panel6.setLayout(null); 
        
        JLabel label1= new JLabel();
        label1.setText("FUNCIONALIDAD");
        label1.setBounds(50, -150, 315,500);
        label1.setFont(new Font ("Arial Black",Font.PLAIN,20));
        label1.setForeground(Color.black);
        
        panel6.add(label1);
        
        JButton boton16=new JButton ();
        boton16.setText("Colaboradores");
        boton16.setFont(new Font ("Arial Black",Font.PLAIN,18));
        boton16.setForeground(Color.white);
         boton16.setBackground(Color.black);
         boton16.setBorder(null);
        boton16.setBounds(145, 415, 144, 25);
     //   boton11.setIcon(new ImageIcon("imagenes/Enviar.png"));
     
        
        panel6.add(boton16);
    
        
         ActionListener ac = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                colaboradores2 op3=new colaboradores2();
                op3.show();
                dispose();
            }
        };
        
         boton16.addActionListener(ac);
        
        
        String Texto="<html><body>Nuestro proyecto consiste en simular <br> una aplicacion de mensajeria."
                + "Para esto nuestro programa abre dos ventanas,<br>"
                + "esas ventanas funcionan como Chats de usuarios,"
                + "el usuario 1, y el usuario 2;"
                + "Estos intercambian "
                + "mensajes entre ventanas mediante un comando llamado "
                + "APPEND.<br>"
                + "<html><body>";
        
        JLabel text = new JLabel (Texto);
        text.setBounds(0, 0, 315, 500);
        text.setFont(new Font ("Arial Black",Font.PLAIN,13));
        
           
        panel6.add(text);
         
           
        panel6.add(text);
        
          JButton boton11=new JButton ();
        boton11.setText("volver");
        boton11.setFont(new Font ("Arial Black",Font.PLAIN,18));
        boton11.setForeground(Color.white);
         boton11.setBackground(Color.black);
         boton11.setBorder(null);
        boton11.setBounds(0, 415, 144, 25);
     //   boton11.setIcon(new ImageIcon("imagenes/Enviar.png"));
        
        panel6.add(boton11);
    
         ActionListener B = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                principal2 op3=new principal2();
                op3.show();
                dispose();
            }
        };
        
         boton11.addActionListener(B);
        
        
         JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
        fondo2.setBounds(0, -20, 400, 500);
        panel6.add(fondo2);
        
    }
    
      
}
