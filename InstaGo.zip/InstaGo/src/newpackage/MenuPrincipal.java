
package newpackage;

import java.awt.Color;//PROPORCIONA CLASES PARA ESPACIOS DE COLOR
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static javafx.scene.text.Font.font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MenuPrincipal extends JFrame {
   
    
    public MenuPrincipal()
    {
        this.setSize(1000, 604);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        login();
    }
    public void login()
    {
        JPanel login=new JPanel();
        this.getContentPane().add(login);
        login.setLayout(null);
        
        JButton boton2 = new JButton();
        boton2.setBounds(0, 0, 100, 100);
        boton2.setOpaque(false);
        boton2.setContentAreaFilled(false);
        boton2.setBorderPainted(false);
        login.add(boton2);
        
        
        
        
        
      JButton boton1=new JButton();
      boton1.setIcon(new ImageIcon("imagenes/Iniciar.png"));
      boton1.setOpaque(false);
      boton1.setContentAreaFilled(false);
      boton1.setBorderPainted(false);
      boton1.setBounds(420, 320, 100, 200);
      
      login.add(boton1);
        
        JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/FONDOLLL.jpg"));
        fondo2.setBounds(0, 0, 1000, 620);
        login.add(fondo2);
        
        
        
        
        
    
      
       ActionListener accion2 = new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                iniciarsesion v3=new iniciarsesion();
                
                v3.show();
                dispose();
            }
        };
      
      boton1.addActionListener(accion2);
      
      
      
      
    }
    
}
