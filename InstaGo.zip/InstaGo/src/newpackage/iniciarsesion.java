
package newpackage;

import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Locale;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.AncestorListener;




public class iniciarsesion extends JFrame{
        
    public static chat2 cha2;
    public static principal op30; 
      public static principal2 op40; 
    
    public  iniciarsesion()
    {
       this.setSize(600,600);
        this.setTitle("MENU DE INICIO DE SESION");
        this.setLocationRelativeTo(null);
        //this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
     
        inciarsesion2();
    }
    
    private  void inciarsesion2()
    {
       
 
        
        JPanel panel1= new JPanel ();
        panel1.setLayout(null);
        this.getContentPane().add(panel1);
       
             JButton boton2 = new JButton ();
        
        boton2.setBounds(120, 415, 385, 40);
        boton2.setText("VOLVER");
        boton2.setFont(new Font ("COOPER",Font.PLAIN,25));
        boton2.setForeground(Color.black);
        boton2.setOpaque(false);
        boton2.setContentAreaFilled(false);
        boton2.setBorderPainted(false);
        
        boton2.setBorder(null);
            
        panel1.add(boton2);
         
        
         ActionListener b=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                MenuPrincipal princi=new MenuPrincipal();
                princi.show();
                dispose();
                
            }
        };
         
          boton2.addActionListener(b);
 
         JTextField caja1 = new JTextField ();
      
        caja1.setFont(new Font ("COOPER",Font.PLAIN,20));
        caja1.setForeground(Color.white);
        caja1.setBounds(126, 220, 376, 51);
        caja1.setOpaque(false);
        caja1.setBorder(null);
        
        
        
         panel1.add(caja1);
         
         
         JPasswordField caja2 = new JPasswordField ();
      
         caja2.setFont(new Font ("Cooper",Font.PLAIN,20));
        caja2.setForeground(Color.white);
        caja2.setBounds(126, 290, 376, 51);
        caja2.setOpaque(false);
        caja2.setBorder(null);
        
       
        
        panel1.add(caja2);
        
        JButton boton1 = new JButton ();
        
        boton1.setBounds(120, 360, 385, 40);
        boton1.setText("INICIAR SESION");
        boton1.setFont(new Font ("Cooper",Font.PLAIN,25));
        boton1.setForeground(Color.black);
        boton1.setOpaque(false);
        boton1.setContentAreaFilled(false);
        boton1.setBorderPainted(false);
        boton1.setBorder(null);

        panel1.add(boton1);
        
        
       
           ActionListener a=new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
             
                   if(caja1.getText().equals("") || caja2.getText().equals(""))
                           {
                               
                            JOptionPane.showMessageDialog(null, "Campo vacio", "Texto",JOptionPane.WARNING_MESSAGE);
                           
                           }
                   else if(caja1.getText().equals("Norman")&& caja2.getText().equals("clase"))
                   {
                       op30=new principal();
                       
                  
                             op30.setVisible(true);
                               caja1.setText("");
                               caja2.setText("");
            
                   }
                   else if(caja1.getText().equals("Yafeth")&& caja2.getText().equals("hola"))
                   {
                       op40=new principal2();
                      
                       if(op30.isVisible())
                       {
                        op40.show();
                        dispose();
                       }
                       else 
                       {         
                               op40.setVisible(true);
                               caja1.setText("");
                               caja2.setText("");    
                       }    
                   }
                   
                 
                   else 
                   {
                       JOptionPane.showMessageDialog(null, "Usuario o Contraseña Incorrecta", "Texto",JOptionPane.ERROR_MESSAGE);
                           caja1.setText("");
                           caja2.setText("");
                   }
                 
                  
                          
              
               }
           };
           
           boton1.addActionListener(a);
        
            
          
        JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/Contraseña.png"));
        fondo2.setBounds(72, 65, 80, 500);
        panel1.add(fondo2);
        
        JLabel fondo3 = new JLabel ();
        fondo3.setIcon(new ImageIcon("imagenes/Logo.png"));
        fondo3.setBounds(253, -175, 200, 600);
        panel1.add(fondo3);
        
        JLabel fondo1 = new JLabel ();
        fondo1.setIcon(new ImageIcon("imagenes/Usuario.png"));
        fondo1.setBounds(65, -4, 400, 500);
        panel1.add(fondo1);
        
        JLabel fondo = new JLabel ();
        fondo.setIcon(new ImageIcon("imagenes/Fondo.png"));
        fondo.setBounds(0, 0, 600, 600);
        panel1.add(fondo);
        
  
    }
}
