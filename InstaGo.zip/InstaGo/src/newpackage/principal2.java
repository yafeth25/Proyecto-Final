
package newpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static newpackage.principal.panel6;


public class principal2 extends JFrame{
    
    
    public principal2()
    {
         this.setSize(315, 500);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
      //  this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
     
        inciarsesion6();
    }
    
    private void inciarsesion6()
    {
       
        
         panel6=new JPanel();
        this.getContentPane().add(panel6);
        panel6.setLayout(null); 
        
         JLabel bienvenida = new JLabel ();
       // fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
        bienvenida.setText(" Bienvenido ");
        bienvenida.setFont(new Font ("Arial Black",Font.PLAIN,30));
        bienvenida.setForeground(Color.black);
       bienvenida.setBounds(52, -40, 400, 500);
        panel6.add(bienvenida);
        
        JLabel bienvenida2 = new JLabel ();
       // fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
        bienvenida2.setText(" A Nuestra Aplicacion");
        bienvenida2.setFont(new Font ("Arial Black",Font.PLAIN,26));
        bienvenida2.setForeground(Color.black);
       bienvenida2.setBounds(-9, 10, 400, 500);
        panel6.add(bienvenida2);
        
        JButton boton7=new JButton ();
         boton7.setText("Inicio");
           boton7.setFont(new Font ("Arial Black",Font.PLAIN,18));
         boton7.setForeground(Color.white);
         boton7.setBackground(Color.black);
         boton7.setBorder(null);
        boton7.setBounds(0, 38, 155, 28);
        
        panel6.add(boton7);
        
         ActionListener B = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                inicio2 op3=new inicio2();
                op3.show();
                dispose();
            }
        };
        
         boton7.addActionListener(B);
         
         JButton boton8=new JButton ();
         boton8.setText("Amigos");
         boton8.setFont(new Font ("Arial Black",Font.PLAIN,18));
         boton8.setForeground(Color.white);
         boton8.setBackground(Color.black);
         boton8.setBorder(null);
         boton8.setBounds(156, 38, 144, 28);
        
        panel6.add(boton8);
        
         ActionListener c2 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                amigo2 op3=new amigo2();
                op3.show();
                dispose();
            }
        };
        
         boton8.addActionListener(c2);
        
        
        JButton boton11=new JButton ();
        boton11.setText("Volver");
        boton11.setFont(new Font ("Arial Black",Font.PLAIN,18));
        boton11.setForeground(Color.white);
         boton11.setBackground(Color.black);
         boton11.setBorder(null);
        boton11.setBounds(0, 415, 144, 25);
     //   boton11.setIcon(new ImageIcon("imagenes/Enviar.png"));
        
        panel6.add(boton11);
     ActionListener c20 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
               iniciarsesion op3=new iniciarsesion();
                op3.show();
                dispose();
            }
        };
           boton11.addActionListener(c20);
        
         JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
        fondo2.setBounds(0, -20, 400, 500);
        panel6.add(fondo2);
        
    }
    
    
    
    
}
