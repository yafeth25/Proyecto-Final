
package newpackage;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;


public class REGISTRARSE extends JFrame {
    
   public static String[] persona2;
    public static String[] persona1;
    public REGISTRARSE()
    {
        this.setSize(400, 400);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
     //  this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        registrarse();
        
    }
    
    public void registrarse()
    {
        JPanel re=new JPanel();
        this.getContentPane().add(re);
        re.setLayout(null);
        
        JLabel regis=new JLabel();
        regis.setText(" Registrar Usuario ");
        regis.setFont(new Font("Engravers MT",Font.PLAIN,20));
        regis.setBounds(45, 10, 320, 15);
        
        re.add(regis);
        
        
        JLabel regis1=new JLabel();
        regis1.setText("Nombre: ");
        regis1.setBounds(10, 50, 70, 30);
        
        re.add(regis1);
        
        JTextField caja1=new JTextField();
        caja1.setBounds(90, 56, 100, 20);
        
        re.add(caja1);
        
        //////////////////////////////////////////////
         JLabel regis2=new JLabel();
        regis2.setText("Apellido: ");
        regis2.setBounds(10, 100, 70, 30);
        
        re.add(regis2);
        
        JTextField caja2=new JTextField();
        caja2.setBounds(90, 105, 100, 20);
        
        re.add(caja2);
        
        ///////////////////////////////////////////////
        JLabel regis3=new JLabel();
        regis3.setText("Telefono: ");
        regis3.setBounds(10, 140, 70, 30);
        
        re.add(regis3);
        
        JTextField caja3=new JTextField();
        caja3.setBounds(90, 145, 100, 20);
        
        re.add(caja3);
        
        ////////////////////////////////////////////////
        JLabel cont=new JLabel();
        cont.setText("Contraseña: ");
        cont.setBounds(10, 190, 90, 30);
        
        re.add(cont);
        
         JPasswordField  caja4=new  JPasswordField ();
        caja4.setBounds(90, 195, 100, 20);
        
        re.add(caja4);
        ///////////////////////////////////////////////////
        JLabel contConfir=new JLabel();
        contConfir.setText("Confirmar: ");
        contConfir.setBounds(10, 240, 90, 30);
        
        re.add(contConfir);
        
         JPasswordField  caja5=new  JPasswordField ();
        caja5.setBounds(90, 245, 100, 20);
        
        re.add(caja5);
        
        JButton Rboton1=new JButton();
        Rboton1.setText("Aceptar");
        Rboton1.setBounds(250, 290, 90, 30);
        
        re.add(Rboton1);
        
        ActionListener accion1;
        accion1 = new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                String contra;
                String confir;
 
                contra=caja4.getText();
                confir=caja5.getText();
               
                
                //////////////////////////////////////////////////////////
             
                
                if(isNumeric(caja1.getText())==true)
             {
                 JOptionPane.showMessageDialog(null,"En Nombre !No puede operar con Numeros! ");
                 caja1.setText(" ");
             }
             else
             {
                 if(caja1.getText().equals(""))
             {
                 JOptionPane.showMessageDialog(null," Nombre !caja vacia! ");
             }
             else
             {
                 
             }
             }//fin
                //////////////////////////////////////////////////////////////
                  if(isNumeric(caja2.getText())==true)
             {
                 JOptionPane.showMessageDialog(null," En Apelido !No puede operar con Numeros! ");
                 caja2.setText(" ");
             }
             else
             {
                 if(caja2.getText().equals(""))
             {
                 JOptionPane.showMessageDialog(null,"Apelido !caja Basia! ");
             }
             else
             {
                 
             }
             }//fin
             ///////////////////////////////////////////////////////////////////
             
               if(isNumeric(caja3.getText())==false)
             {
                 JOptionPane.showMessageDialog(null," En Telefono !No puede operar con Letras! ");
                  caja3.setText(" ");
             }
             else
             {
                 if(caja3.getText().equals(""))
             {
                 JOptionPane.showMessageDialog(null," Telefono !caja vacia! ");
                
             }
             else
             {
                 
             }
             }//fin
               
               if(caja1.getText().equals("") || caja2.getText().equals("") || caja3.getText().equals(""))
               {
                    JOptionPane.showMessageDialog(null," Es obligatorio llenar todos los campos ");
               }
               else
               {
               if(caja4.getText().equals("") && caja4.getText().equals(""))
               {
                   JOptionPane.showMessageDialog(null," Contraseña !caja vacia! ");
               }
               else
               {
                ////////////////////////////////////////////////////////////
                  if(contra == null ? confir == null : contra.equals(confir))
                {
    
                    JOptionPane.showMessageDialog(null, "Usuario Registrado");
                   caja1.setText(" ");
                   caja2.setText(" ");
                   caja3.setText(" ");
                   caja4.setText(" ");
                   caja5.setText(" ");
  
                }
                else if(contra == null ? confir != null : !contra.equals(confir))
                {
                    JOptionPane.showMessageDialog(null, " La Contraseña no coniciden");
                    caja4.setText(" ");
                    caja5.setText(" ");
                }
               }//fin 2
               }//fin 1
             }
    
        };
        
        Rboton1.addActionListener(accion1);
        
        
        
        
        JButton boton2=new JButton();
        boton2.setText("Volver");
        boton2.setBounds(100, 290, 90, 30);
        
        re.add(boton2);
         ActionListener accion2=new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                MenuPrincipal v1=new MenuPrincipal();
                v1.show();
                dispose();
            }
        };
         
        boton2.addActionListener(accion2);
    
        JTextField caja10=new JTextField();
        caja10.setBounds(250, 130, 100, 25);
    
        re.add(caja10);
        
        JPasswordField caja20=new JPasswordField();
        caja20.setBounds(250, 190, 100, 25);
        
        re.add(caja20);
     
        JButton entrar=new JButton();
        entrar.setText("Aceptar");
        entrar.setBounds(250, 250, 90, 25);
        
        re.add(entrar);
        
         ActionListener accion20 = new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
               
                
                
                if(caja10.getText().equals(caja1.getText()) && caja20.getText().equals(caja4.getText()))
                {
                chat1 cha=new chat1();
                cha.setVisible(true);
               caja1.setText("");
               caja2.setText("");
               
                } 
                else if(caja1.getText().equals("entrar") && caja2.getText().equals("holaaa"))
                {
                chat2 cha2=new chat2();
                cha2.setVisible(true);
                caja1.setText("");
                caja2.setText("");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Contraseña o Usuario Incorrecto");
                    caja1.setText("");
                    caja2.setText("");
                } 
           
            }
        };
        
        entrar.addActionListener(accion20);
        
    
    
    }
    
    
    
      public static boolean isNumeric(String cadena)
    {
        try{
            Integer.parseInt(cadena);
        return true;
        }
        catch (NumberFormatException nfe)
        {
            return false;
        }
    }
    
}
