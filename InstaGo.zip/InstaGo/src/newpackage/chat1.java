
package newpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import static java.time.Clock.system;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.AncestorListener;
import static newpackage.chat2.area2;
import javax.swing.JOptionPane;
import static newpackage.principal.panel6;




public class chat1 extends JFrame{
    
  public static JTextArea area;
      
       
    public chat1 ()
    {
        this.setSize(315, 500);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
       
        
        iniciar4();
        
    }
    
    public void iniciar4()
    {
        JPanel panel4=new JPanel();
        this.getContentPane().add(panel4);
        panel4.setLayout(null); 
        //panel4.setBackground(Color.black);
        
        JLabel chat=new JLabel();
        chat.setText("Norman Bu");
        chat.setFont(new Font("Arial Rounded MT",Font.PLAIN,15));
        chat.setForeground(Color.white);
        chat.setBackground(Color.red);
        chat.setBounds(100, 20, 200, 25);
        
        
        panel4.add(chat);
        
          JButton boton13=new JButton ();
     
         boton13.setIcon(new ImageIcon("imagenes/Atras.png"));
         boton13.setBackground(Color.black);
         boton13.setBorder(null);
         boton13.setBounds(265, 20, 27, 28);
        
        panel4.add(boton13);
          ActionListener amigo2 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                amigo2 op3=new amigo2();
                op3.show();
                dispose();
            }
        };
        boton13.addActionListener(amigo2);
        
        area=new JTextArea();
     area.setFont(new Font ("SYSTEM",Font.PLAIN,13));
        area.setBounds(0, 63, 300, 350);
        
        area.setBackground(Color.white);
        area.setLineWrap(true);
        
        
        panel4.add(area);
      
        
       JTextField cajat1=new  JTextField();
       cajat1.setBorder(null);
       cajat1.setFont(new Font ("SYSTEM",Font.PLAIN,13));
       cajat1.setBackground(Color.white);
       cajat1.setForeground(Color.black);
       cajat1.setBounds(24, 421, 225, 35);
   
        panel4.add(cajat1);
        
        
         JButton boton7=new JButton ();
        // boton7.setText("Enviar");
         boton7.setBackground(Color.black);
         boton7.setBorder(null);
        boton7.setBounds(265, 426, 27, 25);
        boton7.setIcon(new ImageIcon("imagenes/Enviar.png"));
        
        panel4.add(boton7);
    
      ActionListener accion1 = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
    
         if(cajat1.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, " Campo Vacio ", "Texto",JOptionPane.QUESTION_MESSAGE);
        }
        else
        {     
           area2.append("-----------------------"+"\n"+"  De Norman: "+cajat1.getText()+"\n\n");
           area.append("\t\t......................"+"\n"+" \t\t    Tu: "+cajat1.getText()+"\n\n");  
          cajat1.setText("");
        }
            }
        };
        
      boton7.addActionListener(accion1);
        
       JLabel fondo2 = new JLabel ();
        fondo2.setIcon(new ImageIcon("imagenes/CHAT.png"));
        fondo2.setBounds(0, -20, 400, 500);
        panel4.add(fondo2);
        
        
    }  
    
    
    
}
