
package newpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static newpackage.principal.panel6;

public class colaboradores1  extends JFrame
{
    public  colaboradores1()
    {
        this.setSize(315, 500);
        this.setTitle("InstaGo");
        this.setFont( new Font("Arial",Font.PLAIN,30));
        this.setLocationRelativeTo(null);
        cola ();
    }
    private void cola ()
            
             {
                 JPanel p1=new JPanel();
                  this.getContentPane().add(p1);
                  p1.setLayout(null);
                  
                  JLabel in=new JLabel();
                  in.setText("Integrantes");
                  in.setBounds(70, -150, 315,500);
                  in.setFont(new Font ("Arial Black",Font.PLAIN,28));
                  in.setForeground(Color.black);
                  p1.add(in);

                 String Texto="<html><body><center>"
               + "Norman Alexis Bu.<br>"
                + "Walter Yafeth Sanchez.<br>"
                + "<html><body>";
        
        JLabel text = new JLabel (Texto);
        text.setBounds(0, 0, 315, 500);
        text.setFont(new Font ("Arial Black",Font.PLAIN,23));
        p1.add(text);
       
                 
                 
                 
                 JButton bo1 =new JButton ();
                 bo1.setText("Volver");
                 bo1.setFont(new Font ("Arial Black",Font.PLAIN,18));
                 bo1.setForeground(Color.white);
                 bo1.setBackground(Color.black);
                 bo1.setBorder(null);
                 bo1.setBounds(0, 415, 144, 25);
                 p1.add(bo1);
                 
                   ActionListener B = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                inicio op3=new inicio();
                op3.show();
                dispose();
            }
        };
        
         bo1.addActionListener(B);
                 
                   JLabel fondo2 = new JLabel ();
                  fondo2.setIcon(new ImageIcon("imagenes/CHAT3.png"));
                  fondo2.setBounds(0, -20, 400, 500);
                  p1.add(fondo2);
             }
    
    
    
}
